{-# LANGUAGE DeriveGeneric #-}
module TrafficLogic where

import Data.Aeson
import GHC.Generics

data LightColor = Red | Yellow | Green deriving (Show, Eq, Generic)
instance ToJSON LightColor
instance FromJSON LightColor

data Direction = North | South | East | West deriving (Show, Eq, Generic)
instance ToJSON Direction
instance FromJSON Direction

data Light = Light {
    direction :: Direction,
    color :: LightColor
} deriving (Show, Eq, Generic)
instance ToJSON Light
instance FromJSON Light

data IntersectionState = IntersectionState {
    lights :: [Light],
    isManual :: Bool,
    activeDirection :: Direction,
    timer :: Int,
    paused :: Bool
} deriving (Show, Eq, Generic)
instance ToJSON IntersectionState
instance FromJSON IntersectionState

initialState :: IntersectionState
initialState = IntersectionState {
    lights = [ Light North Green, Light South Green
             , Light East Red, Light West Red ],
    isManual = False,
    activeDirection = North,
    timer = 50,
    paused = False
}

-- Manual override
setSignalOverride :: Direction -> LightColor -> IntersectionState -> IntersectionState
setSignalOverride dir col state =
    let 
        updateLight l@(Light d c) = if d == dir then Light d col else l
    in state { lights = map updateLight (lights state) }

-- Step function for auto mode
stepSimulation :: IntersectionState -> IntersectionState
stepSimulation state
    | paused state || isManual state = state
    | timer state > 0 = state { timer = timer state - 1 }
    | otherwise = 
        let nextDir = case activeDirection state of
                        North -> East
                        East -> South
                        South -> West
                        West -> North
            currColor = color (head [l | l <- lights state, direction l == activeDirection state])
        in 
            if currColor == Green then
                -- transition to yellow for active pairs
                state { lights = [ Light d (if d == activeDirection state || d == opposite (activeDirection state) then Yellow else Red) | d <- [North, South, East, West] ],
                        timer = 20 }
            else if currColor == Yellow then
                -- transition to next direction's green
                state { activeDirection = nextDir,
                        lights = [ Light d (if d == nextDir || d == opposite nextDir then Green else Red) | d <- [North, South, East, West] ],
                        timer = 80 }
            else state 
  where 
    opposite North = South
    opposite South = North
    opposite East = West
    opposite West = East

setMode :: Bool -> IntersectionState -> IntersectionState
setMode aiModeEnabled state = state { isManual = not aiModeEnabled }

setPaused :: Bool -> IntersectionState -> IntersectionState
setPaused pauseState state = state { paused = pauseState }
