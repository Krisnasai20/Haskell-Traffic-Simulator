// simulation.js
// Standalone Simulation State to handle traffic lights purely in the browser

window.currentIntersectionState = {
    lights: [
        { direction: 'North', color: 'Green' },
        { direction: 'South', color: 'Green' },
        { direction: 'East', color: 'Red' },
        { direction: 'West', color: 'Red' }
    ],
    isManual: false,
    activeDirection: 'North',
    timer: 50,
    paused: true
};

const opposite = {
    'North': 'South',
    'South': 'North',
    'East': 'West',
    'West': 'East'
};

const nextDir = {
    'North': 'East',
    'East': 'South',
    'South': 'West',
    'West': 'North'
};

function stepSimulation() {
    let state = window.currentIntersectionState;
    if (state.paused || state.isManual) return;

    if (state.timer > 0) {
        // Smart Adaptive Sensors
        if (state.timer === 20 && window.getVehicles) {
            const currLight = state.lights.find(l => l.direction === state.activeDirection);
            if (currLight && currLight.color === 'Green') {
                const activePair = [state.activeDirection, opposite[state.activeDirection]];

                // Count vehicles queued up or approaching the intersection in the active lanes
                const waitingCars = window.getVehicles().filter(v => {
                    return activePair.includes(v.dir) && !v.passedCenter &&
                        ((v.dir === 'North' && v.y < 180 && v.y > 80) ||
                            (v.dir === 'South' && v.y > 380 && v.y < 480) ||
                            (v.dir === 'East' && v.x > 380 && v.x < 480) ||
                            (v.dir === 'West' && v.x < 180 && v.x > 80));
                });

                // If there's a traffic jam and we haven't already extended this cycle
                if (waitingCars.length >= 3 && !state.extended) {
                    state.timer += 60; // Extend Green light by 6 seconds!
                    state.extended = true;
                }
            }
        }
        state.timer--;
    } else {
        const currPair = [state.activeDirection, opposite[state.activeDirection]];
        const currLight = state.lights.find(l => l.direction === state.activeDirection);

        if (currLight.color === 'Green') {
            // transition to yellow for active pairs
            state.lights.forEach(l => {
                if (currPair.includes(l.direction)) l.color = 'Yellow';
                else l.color = 'Red';
            });
            state.timer = 20; // yellow light duration
        } else if (currLight.color === 'Yellow') {
            // transition to next direction's green
            state.activeDirection = nextDir[state.activeDirection];
            const nextPair = [state.activeDirection, opposite[state.activeDirection]];
            state.lights.forEach(l => {
                if (nextPair.includes(l.direction)) l.color = 'Green';
                else l.color = 'Red';
            });
            state.timer = 80; // green light duration
            state.extended = false; // reset extension flag
        }
    }
}

function updateIntersectionUI(lights) {
    lights.forEach(light => {
        const dir = light.direction;
        const color = light.color;

        const container = document.getElementById(`tl-${dir}`);
        if (container) {
            container.querySelector('.red').classList.remove('active');
            container.querySelector('.yellow').classList.remove('active');
            container.querySelector('.green').classList.remove('active');
            container.querySelector(`.${color.toLowerCase()}`).classList.add('active');
        }

        const dot = document.getElementById(`dot-${dir}`);
        if (dot) {
            dot.className = `status-dot ${color.toLowerCase()}`;
        }
    });
}

// Local simulation loop runs every 100ms
setInterval(() => {
    stepSimulation();
    updateIntersectionUI(window.currentIntersectionState.lights);
}, 100);

window.refreshSimulationState = () => updateIntersectionUI(window.currentIntersectionState.lights);

// APIs for script.js to call locally
window.apiOverrideSignal = (lane, signalStr) => {
    const state = window.currentIntersectionState;
    const l = state.lights.find(x => x.direction === lane);
    if (l) l.color = signalStr;

    // Safety feature: If we manually turn a lane Green or Yellow, force perpendicular lanes to Red
    if (signalStr === 'Green' || signalStr === 'Yellow') {
        const isNS = (lane === 'North' || lane === 'South');
        state.lights.forEach(otherLight => {
            const otherIsNS = (otherLight.direction === 'North' || otherLight.direction === 'South');
            if (isNS !== otherIsNS) {
                otherLight.color = 'Red';
            }
        });
    }

    window.refreshSimulationState();
};

window.apiSetMode = (isAi) => {
    window.currentIntersectionState.isManual = !isAi;
};

window.apiSetPaused = (isPaused) => {
    window.currentIntersectionState.paused = isPaused;
};

window.apiReset = () => {
    window.currentIntersectionState = {
        lights: [
            { direction: 'North', color: 'Green' },
            { direction: 'South', color: 'Green' },
            { direction: 'East', color: 'Red' },
            { direction: 'West', color: 'Red' }
        ],
        isManual: false,
        activeDirection: 'North',
        timer: 50,
        paused: true
    };
    if (window.clearVehicles) window.clearVehicles();
    window.refreshSimulationState();
};
