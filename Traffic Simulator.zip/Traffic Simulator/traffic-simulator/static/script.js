// script.js
// Handles UI interactions, control panel buttons, and updates local simulation

// DOM Elements
const aiModeCheckbox = document.getElementById('ai-mode');
const startBtn = document.getElementById('btn-start');
const pauseBtn = document.getElementById('btn-pause');
const resetBtn = document.getElementById('btn-reset');
const ovrLane = document.getElementById('lane-select');
const ovrG = document.getElementById('btn-ovr-g') || document.querySelector('.btn-green-solid');
const ovrY = document.getElementById('btn-ovr-y') || document.querySelector('.btn-yellow-solid');
const ovrR = document.getElementById('btn-ovr-r') || document.querySelector('.btn-red-solid');
const rainToggle = document.getElementById('rain-toggle');
const dayToggle = document.getElementById('day-toggle');
const rainLayer = document.getElementById('rain-layer');
const intersectionArea = document.querySelector('.intersection-area');

// Initial setup from HTML state
window.apiSetMode(aiModeCheckbox.checked);

// Controls
function toggleAI() {
    const isAi = aiModeCheckbox.checked;
    window.apiSetMode(isAi);
}

aiModeCheckbox.addEventListener('change', toggleAI);

if (rainToggle) {
    rainToggle.addEventListener('change', (e) => {
        if (e.target.checked) {
            rainLayer.classList.add('active');
            intersectionArea.classList.add('wet-road');
        } else {
            rainLayer.classList.remove('active');
            intersectionArea.classList.remove('wet-road');
        }
    });
}

if (dayToggle) {
    dayToggle.addEventListener('change', (e) => {
        if (e.target.checked) {
            document.body.classList.add('light-mode');
        } else {
            document.body.classList.remove('light-mode');
        }
    });
}

startBtn.addEventListener('click', () => {
    window.apiSetPaused(false);
});

pauseBtn.addEventListener('click', () => {
    window.apiSetPaused(true);
});

resetBtn.addEventListener('click', () => {
    window.apiReset();
    if (!aiModeCheckbox.checked) {
        aiModeCheckbox.checked = true;
        toggleAI();
    }
});

// Override logic
function overrideSignal(colorStr) {
    const lane = ovrLane.value;

    // Automatically disable AI mode if we manually override a signal
    if (aiModeCheckbox.checked) {
        aiModeCheckbox.checked = false;
        toggleAI();
    }

    window.apiOverrideSignal(lane, colorStr);
}

if (ovrG) ovrG.addEventListener('click', () => overrideSignal('Green'));
if (ovrY) ovrY.addEventListener('click', () => overrideSignal('Yellow'));
if (ovrR) ovrR.addEventListener('click', () => overrideSignal('Red'));
