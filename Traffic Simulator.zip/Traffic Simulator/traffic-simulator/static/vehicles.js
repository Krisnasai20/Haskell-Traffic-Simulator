// Simple vehicle movement simulation engine
const layer = document.getElementById('vehicles-layer');
const addBtns = document.querySelectorAll('.add-veh');
const passedEl = document.getElementById('passed-count');

let vehicles = [];
let pedestrians = [];
let vehiclesPassed = 0;

window.clearVehicles = () => {
    vehicles.forEach(v => v.el.remove());
    pedestrians.forEach(p => p.el.remove());
    vehicles = [];
    pedestrians = [];
    vehiclesPassed = 0;
    if (passedEl) {
        passedEl.innerText = vehiclesPassed;
    }
};

window.getVehicles = () => vehicles;

// Spawn points and directions
const START_POS = {
    'North': { top: -40, left: 275, dy: 1, dx: 0, stopLine: 180 },
    'South': { top: 640, left: 310, dy: -1, dx: 0, stopLine: 380 },
    'East': { top: 275, left: 640, dy: 0, dx: -1, stopLine: 380 },
    'West': { top: 310, left: -40, dy: 0, dx: 1, stopLine: 180 }
};

const PED_START_POS = {
    'North': [
        { x: 210, y: 213, dx: 1, dy: 0, crossLabel: 'North' },
        { x: 390, y: 213, dx: -1, dy: 0, crossLabel: 'North' }
    ],
    'South': [
        { x: 210, y: 377, dx: 1, dy: 0, crossLabel: 'South' },
        { x: 390, y: 377, dx: -1, dy: 0, crossLabel: 'South' }
    ],
    'East': [
        { x: 377, y: 210, dx: 0, dy: 1, crossLabel: 'East' },
        { x: 377, y: 390, dx: 0, dy: -1, crossLabel: 'East' }
    ],
    'West': [
        { x: 213, y: 210, dx: 0, dy: 1, crossLabel: 'West' },
        { x: 213, y: 390, dx: 0, dy: -1, crossLabel: 'West' }
    ]
};

function spawnVehicle(type) {
    const dirSelect = document.getElementById('spawn-dir');
    const intentSelect = document.getElementById('turn-intent');

    const chosenDir = dirSelect ? dirSelect.value : 'Random';
    const chosenIntent = intentSelect ? intentSelect.value : 'Random';

    let dirs = ['North', 'South', 'East', 'West'];
    if (chosenDir !== 'Random') {
        dirs = [chosenDir];
    } else {
        dirs.sort(() => Math.random() - 0.5);
    }

    let dir = null;
    let settings = null;

    for (let d of dirs) {
        let s = START_POS[d];
        let isOccupied = vehicles.some(v => v.dir === d && Math.abs(v.x - s.left) < 70 && Math.abs(v.y - s.top) < 70);
        if (!isOccupied) {
            dir = d;
            settings = s;
            break;
        }
    }

    if (!dir) return; // All spawn points occupied

    const el = document.createElement('div');
    el.className = `vehicle ${type} dir-${dir.toLowerCase()}`;

    // Ambulances have flashing lights effect
    if (type === 'ambulance') {
        el.innerHTML = '<div class="siren"></div>';
    }

    let y = settings.top;
    let x = settings.left;

    let intent = 'straight';
    if (type !== 'ambulance') {
        if (chosenIntent !== 'Random') {
            intent = chosenIntent;
        } else {
            const r = Math.random();
            if (r < 0.2) intent = 'left';
            else if (r < 0.4) intent = 'right';
        }
    }

    if (intent !== 'straight') {
        el.classList.add(`intent-${intent}`);
    }

    el.style.top = `${y}px`;
    el.style.left = `${x}px`;
    layer.appendChild(el);

    // Read speed multiplier
    const speedSelect = document.getElementById('speed-limit');
    const speedMult = speedSelect ? parseFloat(speedSelect.value) : 1.0;

    let baseSpeed = (type === 'ambulance') ? 4.0 : (2.0 + Math.random());

    vehicles.push({
        el,
        type,
        dir,
        x,
        y,
        speed: baseSpeed * speedMult,
        passedCenter: false,
        intent,
        turned: false,
        ...settings
    });
}

addBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        spawnVehicle(btn.dataset.type);
    });
});

document.querySelector('.add-ped').addEventListener('click', () => {
    const crosswalks = ['North', 'South', 'East', 'West'];
    const cw = crosswalks[Math.floor(Math.random() * crosswalks.length)];
    const options = PED_START_POS[cw];
    const settings = options[Math.floor(Math.random() * options.length)];

    const el = document.createElement('div');
    el.className = `pedestrian`;
    let x = settings.x;
    let y = settings.y;

    el.style.top = `${y}px`;
    el.style.left = `${x}px`;
    layer.appendChild(el);

    pedestrians.push({
        el,
        x,
        y,
        dx: settings.dx,
        dy: settings.dy,
        cw: settings.crossLabel,
        speed: 0.8 + Math.random() * 0.4
    });
});

function isPerpendicular(dir1, dir2) {
    const ns = ['North', 'South'];
    const ew = ['East', 'West'];
    return (ns.includes(dir1) && ew.includes(dir2)) || (ew.includes(dir1) && ns.includes(dir2));
}

function isInIntersectionBox(v) {
    return v.x > 180 && v.x < 420 && v.y > 180 && v.y < 420;
}

function isApproachingIntersectionBox(v) {
    if (v.dir === 'North') return v.y > 100 && v.y <= 180;
    if (v.dir === 'South') return v.y < 500 && v.y >= 380;
    if (v.dir === 'East') return v.x < 500 && v.x >= 380;
    if (v.dir === 'West') return v.x > 100 && v.x <= 180;
    return false;
}

function isNearIntersectionGeneral(v) {
    return v.x > 100 && v.x < 500 && v.y > 100 && v.y < 500;
}

function hasPassedIntersection(v) {
    if (v.dir === 'North' && v.y > 400) return true;
    if (v.dir === 'South' && v.y < 200) return true;
    if (v.dir === 'East' && v.x < 200) return true;
    if (v.dir === 'West' && v.x > 400) return true;
    return false;
}

// Main loop for vehicles
function vehicleLoop() {
    const state = window.currentIntersectionState;
    if (!state || state.paused) {
        requestAnimationFrame(vehicleLoop);
        return;
    }

    const lightsDict = {};
    if (state && state.lights) {
        state.lights.forEach(l => lightsDict[l.direction] = l.color);
    }

    const activeAmbulances = vehicles.filter(o => o.type === 'ambulance' && isNearIntersectionGeneral(o) && !hasPassedIntersection(o));

    vehicles.forEach((v, index) => {
        let shouldMove = true;
        let isAmbulance = v.type === 'ambulance';

        let yieldToAmbulance = false;
        if (!isAmbulance && activeAmbulances.length > 0) {
            for (let a of activeAmbulances) {
                if (isPerpendicular(v.dir, a.dir)) {
                    yieldToAmbulance = true;
                    break;
                }
            }
        }

        // Red light logic (Ambulances ignore red lights)
        const light = lightsDict[v.dir];
        if (!isAmbulance && light !== 'Green') {
            if (v.dir === 'North' && v.y >= v.stopLine - 40 && v.y <= v.stopLine) shouldMove = false;
            if (v.dir === 'South' && v.y <= v.stopLine + 40 && v.y >= v.stopLine) shouldMove = false;
            if (v.dir === 'East' && v.x <= v.stopLine + 40 && v.x >= v.stopLine) shouldMove = false;
            if (v.dir === 'West' && v.x >= v.stopLine - 40 && v.x <= v.stopLine) shouldMove = false;
        }

        // Yield to ambulance logic
        if (yieldToAmbulance) {
            // Stop cars approaching if an ambulance is near on a perpendicular lane
            if (isApproachingIntersectionBox(v)) {
                shouldMove = false;
            }
        }

        // Yield to pedestrian logic
        if (shouldMove) {
            for (let p of pedestrians) {
                if (!p) continue;
                if (v.dir === 'North' && p.y > v.y && p.y - v.y < 50 && Math.abs(p.x - v.x) < 25) { shouldMove = false; break; }
                if (v.dir === 'South' && p.y < v.y && v.y - p.y < 50 && Math.abs(p.x - v.x) < 25) { shouldMove = false; break; }
                if (v.dir === 'East' && p.x < v.x && v.x - p.x < 50 && Math.abs(p.y - v.y) < 25) { shouldMove = false; break; }
                if (v.dir === 'West' && p.x > v.x && p.x - v.x < 50 && Math.abs(p.y - v.y) < 25) { shouldMove = false; break; }
            }
        }

        // Collision avoidance logic
        if (shouldMove) {
            for (let i = 0; i < vehicles.length; i++) {
                if (i !== index) {
                    const other = vehicles[i];
                    if (!other) continue;

                    // Same lane rear-end avoidance
                    if (other.dir === v.dir) {
                        const d = (v.dx !== 0) ? Math.abs(v.x - other.x) : Math.abs(v.y - other.y);
                        let ahead = false;
                        if (v.dir === 'North' && other.y > v.y) ahead = true;
                        if (v.dir === 'South' && other.y < v.y) ahead = true;
                        if (v.dir === 'East' && other.x < v.x) ahead = true;
                        if (v.dir === 'West' && other.x > v.x) ahead = true;

                        const rainToggle = document.getElementById('rain-toggle');
                        const isRaining = rainToggle && rainToggle.checked;
                        const safeDistance = isRaining ? 110 : 65; // Reduced traction in rain

                        if (ahead && d < safeDistance) { // Maintain larger following distance to prevent clipping
                            shouldMove = false;
                            break;
                        }
                    }
                    // Cross lane intersection avoidance
                    else if (isPerpendicular(v.dir, other.dir)) {
                        // Ignore the other vehicle if it is stopped (or stopping) at a red/yellow light
                        const otherLight = lightsDict[other.dir];
                        const otherIsAmbulance = other.type === 'ambulance';
                        let otherIsBeforeStop = false;
                        if (other.dir === 'North' && other.y <= other.stopLine) otherIsBeforeStop = true;
                        if (other.dir === 'South' && other.y >= other.stopLine) otherIsBeforeStop = true;
                        if (other.dir === 'East' && other.x >= other.stopLine) otherIsBeforeStop = true;
                        if (other.dir === 'West' && other.x <= other.stopLine) otherIsBeforeStop = true;

                        if (!otherIsAmbulance && otherLight !== 'Green' && otherIsBeforeStop) {
                            continue; // The other vehicle will stop, no need to yield to it
                        }

                        // Very simple: if they are near each other in the intersection, the one closer to the center wins, 
                        // or if roughly equal, use the index as a tie breaker to guarantee no infinite deadlocks
                        const distToCenterX = Math.abs(v.x - 300);
                        const distToCenterY = Math.abs(v.y - 300);
                        const myDist = distToCenterX + distToCenterY;

                        const otherDistX = Math.abs(other.x - 300);
                        const otherDistY = Math.abs(other.y - 300);
                        const otherDist = otherDistX + otherDistY;

                        // Only care if both are dangerously close to the center
                        if (myDist < 150 && otherDist < 150) {
                            if (myDist > otherDist + 10) {
                                // I am further away, yield
                                shouldMove = false;
                                break;
                            } else if (Math.abs(myDist - otherDist) <= 10 && index < i) {
                                // Tie breaker
                                shouldMove = false;
                                break;
                            }
                        }
                    }
                }
            }
        }

        // Turn logic
        if (!v.turned && v.intent !== 'straight') {
            let shouldTurn = false;
            let targetDir = '';
            let targetX = v.x;
            let targetY = v.y;
            let newDx = 0;
            let newDy = 0;

            if (v.dir === 'North') { // Going South
                if (v.intent === 'right' && v.y >= 275) { shouldTurn = true; targetDir = 'East'; targetY = 275; newDx = -1; }
                else if (v.intent === 'left' && v.y >= 310) { shouldTurn = true; targetDir = 'West'; targetY = 310; newDx = 1; }
            } else if (v.dir === 'South') { // Going North
                if (v.intent === 'right' && v.y <= 310) { shouldTurn = true; targetDir = 'West'; targetY = 310; newDx = 1; }
                else if (v.intent === 'left' && v.y <= 275) { shouldTurn = true; targetDir = 'East'; targetY = 275; newDx = -1; }
            } else if (v.dir === 'East') { // Going West
                if (v.intent === 'right' && v.x <= 310) { shouldTurn = true; targetDir = 'South'; targetX = 310; newDy = -1; }
                else if (v.intent === 'left' && v.x <= 275) { shouldTurn = true; targetDir = 'North'; targetX = 275; newDy = 1; }
            } else if (v.dir === 'West') { // Going East
                if (v.intent === 'right' && v.x >= 275) { shouldTurn = true; targetDir = 'North'; targetX = 275; newDy = 1; }
                else if (v.intent === 'left' && v.x >= 310) { shouldTurn = true; targetDir = 'South'; targetX = 310; newDy = -1; }
            }

            if (shouldTurn) {
                v.turned = true;
                v.el.classList.remove(`dir-${v.dir.toLowerCase()}`);
                v.el.classList.add(`dir-${targetDir.toLowerCase()}`);
                v.el.classList.remove('intent-left');
                v.el.classList.remove('intent-right');

                v.dir = targetDir;
                v.dx = newDx;
                v.dy = newDy;
                v.x = targetX;
                v.y = targetY;
                v.intent = 'straight';
            }
        }

        if (shouldMove) {
            v.x += v.dx * v.speed;
            v.y += v.dy * v.speed;
            v.el.style.left = `${v.x}px`;
            v.el.style.top = `${v.y}px`;
        }

        // Count vehicles that have successfully passed the main intersection
        if (!v.passedCenter && hasPassedIntersection(v)) {
            v.passedCenter = true;
            vehiclesPassed++;
            if (passedEl) {
                passedEl.innerText = vehiclesPassed;
                // Add a little pop effect
                passedEl.style.transform = "scale(1.5)";
                setTimeout(() => passedEl.style.transform = "scale(1)", 200);
            }
        }

        // Remove if significantly out of bounds
        if (v.x < -100 || v.x > 700 || v.y < -100 || v.y > 700) {
            v.el.remove();
            vehicles[index] = null;
        }
    });

    vehicles = vehicles.filter(v => v !== null);

    // Pedestrian logic
    pedestrians.forEach((p, index) => {
        let shouldMove = true;
        // The crosswalk North/South runs parallel to East/West roads, requiring North/South traffic to be RED
        let isAtCurb = false;
        if (p.cw === 'North' || p.cw === 'South') {
            if (p.dx === 1 && p.x <= 225) isAtCurb = true;
            if (p.dx === -1 && p.x >= 375) isAtCurb = true;
        } else {
            if (p.dy === 1 && p.y <= 225) isAtCurb = true;
            if (p.dy === -1 && p.y >= 375) isAtCurb = true;
        }

        const intersectingTrafficGreen = (lightsDict[p.cw] !== 'Red');
        if (isAtCurb && intersectingTrafficGreen) {
            shouldMove = false; // Stop at curb safely
        }

        if (shouldMove) {
            p.x += p.dx * p.speed;
            p.y += p.dy * p.speed;
            p.el.style.left = `${p.x}px`;
            p.el.style.top = `${p.y}px`;
        }

        const outOfBounds = (p.cw === 'North' || p.cw === 'South') ? (p.x < 190 || p.x > 410) : (p.y < 190 || p.y > 410);
        if (outOfBounds) {
            p.el.remove();
            pedestrians[index] = null;
        }
    });

    pedestrians = pedestrians.filter(p => p !== null);

    requestAnimationFrame(vehicleLoop);
}

requestAnimationFrame(vehicleLoop);

// Periodic auto-spawn removed per user request
