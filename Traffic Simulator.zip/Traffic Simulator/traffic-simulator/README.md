# Smart Traffic Simulator

A functional logic engine powered by Haskell to simulate a web-based smart traffic junction.

## Features
- Pure functional core written in Haskell tracking intersection state.
- Scotty-based JSON REST API.
- Fully simulated physics/animation for vehicles in JS.
- Beautiful, high-quality, aesthetic dark city interface.
- Manual Override control: users can manually command specific colors (Red, Yellow, Green) for a particular lane.

## Structure
- `app.hs` & `server.hs` & `trafficLogic.hs`: Haskell Backend Logic.
- `static/*` and `templates/*`: HTML / CSS / JS Frontend Interface.
- `data/trafficData.json`: Data placeholder for save states or initial configurations.
- `traffic-simulator.cabal`: Project dependency definitions.

## How to run
1. Ensure Haskell (`GHC` and `cabal`) is installed.
2. `cabal run traffic-simulator`
3. Open `http://localhost:3000` in your web browser.

You can toggle "Adaptive AI Mode". When uncontrolled (box checked), the Haskell functional loop processes signal changes automatically. To "control red lights by me", uncheck it, select a lane, and hit the Red Override button (R).
