module Main where

import Control.Concurrent.STM
import Server (runServer)
import TrafficLogic (initialState)

main :: IO ()
main = do
    putStrLn "Starting Smart Traffic Simulator..."
    putStrLn "Server running on http://localhost:3000"
    stateVar <- newTVarIO initialState
    runServer stateVar
