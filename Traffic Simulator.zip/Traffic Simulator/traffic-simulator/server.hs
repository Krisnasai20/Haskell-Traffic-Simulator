{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE DeriveGeneric #-}
module Server (runServer, AppState) where

import Web.Scotty
import Network.Wai.Middleware.Static
import Network.HTTP.Types.Status (status200)
import Data.Aeson (FromJSON, ToJSON)
import GHC.Generics (Generic)
import Control.Monad.IO.Class (liftIO)
import Control.Concurrent.STM
import Control.Concurrent (forkIO, threadDelay)

import TrafficLogic

type AppState = TVar IntersectionState

data OverrideRequest = OverrideRequest {
    lane :: Direction,
    signal :: LightColor
} deriving (Generic, Show)

instance FromJSON OverrideRequest

data ModeRequest = ModeRequest {
    aiMode :: Bool
} deriving (Generic, Show)

instance FromJSON ModeRequest

data PauseRequest = PauseRequest {
    isPaused :: Bool
} deriving (Generic, Show)

instance FromJSON PauseRequest

runServer :: AppState -> IO ()
runServer stateVar = do
    forkIO $ simulationLoop stateVar

    scotty 3000 $ do
        middleware $ staticPolicy (noDots >-> addBase "static")
        
        get "/" $ file "templates/index.html"
        
        get "/api/state" $ do
            state <- liftIO $ readTVarIO stateVar
            json state
            
        post "/api/override" $ do
            req <- jsonData :: ActionM OverrideRequest
            liftIO $ atomically $ modifyTVar' stateVar (setSignalOverride (lane req) (signal req))
            status status200
            
        post "/api/mode" $ do
            req <- jsonData :: ActionM ModeRequest
            liftIO $ atomically $ modifyTVar' stateVar (setMode (aiMode req))
            status status200
            
        post "/api/pause" $ do
            req <- jsonData :: ActionM PauseRequest
            liftIO $ atomically $ modifyTVar' stateVar (setPaused (isPaused req))
            status status200
            
        post "/api/reset" $ do
            liftIO $ atomically $ writeTVar stateVar initialState
            status status200

simulationLoop :: AppState -> IO ()
simulationLoop stateVar = loop
  where
    loop = do
        threadDelay 100000 -- 100ms
        atomically $ modifyTVar' stateVar stepSimulation
        loop
